package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Jdbc_PrepareStatement {

    static Connection conn = null;
    Scanner kk = new Scanner(System.in);
    int ch;

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String dburl = "jdbc:mysql://localhost:3306/student";
            conn = DriverManager.getConnection(dburl, "root", "");
            Jdbc_PrepareStatement obj = new Jdbc_PrepareStatement();
            int ch;
            do {
                System.out.println("1.Insert");
                System.out.println("2.Update");
                System.out.println("3.Delete");
                System.out.println("4.Display");
                System.out.println("0.Exit");
                System.out.println("Enter your choice:- ");
                ch = obj.kk.nextInt();
                switch (ch) {
                    case 1:
                        obj.insert();
                        break;
                    case 2:
                        obj.update();
                        break;
                    case 3:
                        obj.delete();
                        break;
                    case 4:
                        obj.display();

                }
            } while (ch != 0);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Jdbc_PrepareStatement.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    void insert() {
        try {
            System.out.println("Enter a name:- ");
            String name = kk.next();
            System.out.println("Enter a age:- ");
            int age = kk.nextInt();
            System.out.println("Enter a gender:- ");
            String gender = kk.next();
            System.out.println("Enter a city:- ");
            String city = kk.next();
            String insertsql = "insert into stud value(null,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(insertsql);
            ps.setString(1, name);
            ps.setInt(2, age);
            ps.setString(3, gender);
            ps.setString(4, city);
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Jdbc_PrepareStatement.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void display() throws SQLException {
        PreparedStatement ps = conn.prepareStatement("select * from stud");
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            System.out.print(rs.getInt("id") + " ");
            System.out.print(rs.getString("name") + " ");
            System.out.print(rs.getInt("age") + " ");
            System.out.print(rs.getString("gender") + " ");
            System.out.print(rs.getString("city") + "\n");
        }
    }

    void delete() throws SQLException {
        System.out.println("Enter a id to delete");
        int id = kk.nextInt();
        PreparedStatement ps = conn.prepareStatement("delete from stud where id=?");
        ps.setInt(1, id);
        ps.executeUpdate();
    }

    void update() throws SQLException {
        System.out.println("Enter a id to update");
        int id = kk.nextInt();
        System.out.println("Enter a name:- ");
        String name = kk.next();
        System.out.println("Enter a age:- ");
        int age = kk.nextInt();
        System.out.println("Enter a gender:- ");
        String gender = kk.next();
        System.out.println("Enter a city:- ");
        String city = kk.next();
        PreparedStatement ps = conn.prepareStatement("update stud set name=?,age=?,gender=?,city=? where id=?");
        ps.setString(1, name);
        ps.setInt(2, age);
        ps.setString(3, gender);
        ps.setString(4, city);
        ps.setInt(5, id);
        ps.executeUpdate();
    }
}