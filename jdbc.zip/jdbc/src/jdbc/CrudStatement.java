package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CrudStatement {

    static Connection conn = null;
    Scanner kk = new Scanner(System.in);

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        String dburl = "jdbc:mysql://localhost:3306/student";
        conn = DriverManager.getConnection(dburl, "root", "");
        CrudStatement obj = new CrudStatement();
        int ch;
        do {
            System.out.println("||----------------Statement----------------||");
            System.out.println("1.Insert");
            System.out.println("2.Update");
            System.out.println("3.Delete");
            System.out.println("4.Display");
            System.out.println("0.Exit");
            System.out.println("Enter your choice:- ");
            ch = obj.kk.nextInt();
            switch (ch) {
                case 1:
                    obj.insert();
                    break;
                case 2:
                    obj.update();
                    break;
                case 3:
                    obj.delete();
                    break;
                case 4:
                    obj.display();

            }
        } while (ch != 0);
    }

    void insert() throws SQLException {

        System.out.println("Enter a name:- ");
        String name = kk.next();
        System.out.println("Enter a age:- ");
        int age = kk.nextInt();
        System.out.println("Enter a gender:- ");
        String gender = kk.next();
        System.out.println("Enter a city:- ");
        String city = kk.next();
        String insertsql = "insert into stud value(null,'" + name + "', " + age + ",'" + gender + "','" + city + "' )";
        Statement ps = conn.createStatement();
        ps.executeUpdate(insertsql);

    }

    void display() throws SQLException {
        Statement ps = conn.createStatement();

        ResultSet rs = ps.executeQuery("select * from stud");
        while (rs.next()) {
            System.out.print(rs.getInt("id") + " ");
            System.out.print(rs.getString("name") + " ");
            System.out.print(rs.getInt("age") + " ");
            System.out.print(rs.getString("gender") + " ");
            System.out.print(rs.getString("city") + "\n");
        }
    }

    void delete() throws SQLException {
        System.out.println("Enter a id to delete");
        int id = kk.nextInt();
        Statement ps = conn.createStatement();
        ps.executeUpdate("delete from stud where id=" + id + "");
    }

    void update() throws SQLException {
        System.out.println("Enter a id to update");
        int id = kk.nextInt();
        System.out.println("Enter a name:- ");
        String name = kk.next();
        System.out.println("Enter a age:- ");
        int age = kk.nextInt();
        System.out.println("Enter a gender:- ");
        String gender = kk.next();
        System.out.println("Enter a city:- ");
        String city = kk.next();
        Statement ps = conn.createStatement();

        ps.executeUpdate("update stud set name= '" + name + "' ,age=" + age + ",gender='" + gender + "',city='" + city + "' where id=" + id + "");
    }
}
