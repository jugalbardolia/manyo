package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class handleOperation extends HttpServlet {

    static Connection conn = null;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String dburl = "jdbc:mysql://localhost:3306/student";
            conn = DriverManager.getConnection(dburl, "root", "");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(handleOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
//------------------------------------------------------------------------------------------------------------------------------------
        if ("login".equals(req.getParameter("login"))) {
            String email = req.getParameter("email");
            String password = req.getParameter("password");
            try {
                PreparedStatement ps = conn.prepareStatement("select * from studlogin where email= '"+email+"' and password= '"+password+"' ");
//              ps.setString(1, email);
//              ps.setString(2, password);
                ResultSet rs = ps.executeQuery();
                int count = 0;
                if (rs.next()) {
                    out.print("login success");
                    HttpSession session=req.getSession();
                    session.setAttribute("email", rs.getString("email"));
                }
                else
                {
                    out.print("unsuccess");
                }
                
                
            } catch (SQLException ex) {
                Logger.getLogger(handleOperation.class.getName()).log(Level.SEVERE, null, ex);
            }

            //------------------------------------------------------------------------------------------------------------------------------------
        } else if ("register".equals(req.getParameter("register"))) {
            String name = req.getParameter("name");
            String email = req.getParameter("email");
            String city = req.getParameter("city");
            String password = req.getParameter("password");
            String cpassword = req.getParameter("cpassword");
            if (password.equals(cpassword)) {
                try {

                    PreparedStatement ps = conn.prepareStatement("insert into studlogin values(null,?,?,?,?)");
                    ps.setString(1, name);
                    ps.setString(2, city);
                    ps.setString(3, password);
                    ps.setString(4, email);
                    out.print(name + " ");
                    out.print(email + " ");
                    out.print(city + " ");
                    out.print(password + " ");
                    ps.executeUpdate();
                    resp.sendRedirect("register.html");
                } catch (SQLException ex) {
                    Logger.getLogger(handleOperation.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                out.print("<script>alert('Password is mismatch');</script>");
                req.getRequestDispatcher("register.html").include(req, resp);
            }
        }
    }
}
